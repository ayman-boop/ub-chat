# UB Chat - Anonymous Discussion Platform

An anonymous chat platform exclusively for University at Buffalo students.

## Features

- **UB-Only Access**: Only @buffalo.edu email addresses can register
- **Complete Anonymity**: Users are identified by random handles (e.g., "BlueBull1234")
- **Thread-Based Discussions**: Organized by professors, courses, and general topics
- **Real-time Chat**: Instant message updates using Socket.io
- **Content Moderation**: Automated flagging for inappropriate content

## Tech Stack

- **Frontend**: Next.js with TypeScript and Tailwind CSS
- **Backend**: Next.js API routes (Node.js)
- **Real-time Communication**: Socket.io
- **Database**: MongoDB with Mongoose
- **Authentication**: Firebase Auth with email link sign-in

## Getting Started

### Prerequisites

- Node.js (v16+)
- npm or yarn
- MongoDB database
- Firebase project

### Environment Variables

Create a `.env.local` file in the project root with the following variables:

```
# MongoDB
MONGODB_URI=your_mongodb_connection_string

# Firebase (Backend)
FIREBASE_API_KEY=your_firebase_api_key
FIREBASE_AUTH_DOMAIN=your_firebase_auth_domain
FIREBASE_PROJECT_ID=your_firebase_project_id
FIREBASE_STORAGE_BUCKET=your_firebase_storage_bucket
FIREBASE_MESSAGING_SENDER_ID=your_firebase_messaging_sender_id
FIREBASE_APP_ID=your_firebase_app_id

# Firebase (Frontend)
NEXT_PUBLIC_FIREBASE_API_KEY=your_firebase_api_key
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your_firebase_auth_domain
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your_firebase_project_id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your_firebase_storage_bucket
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=your_firebase_messaging_sender_id
NEXT_PUBLIC_FIREBASE_APP_ID=your_firebase_app_id
```

### Installation

1. Clone the repository
2. Install dependencies:
   ```bash
   npm install
   ```
3. Start the development server:
   ```bash
   npm run dev
   ```
4. Open [http://localhost:3000](http://localhost:3000) in your browser

## Project Structure

- `/app`: Next.js app router pages and layouts
- `/app/api`: API routes
- `/components`: Reusable React components
- `/lib`: Utility functions and configuration
- `/models`: Mongoose models
- `/public`: Static assets
- `/styles`: Global CSS styles

## Deployment

This project can be deployed on Vercel, Netlify, or any platform that supports Next.js applications.

## License

MIT

## Acknowledgements

Built for University at Buffalo students to facilitate anonymous discussions about academic life. 